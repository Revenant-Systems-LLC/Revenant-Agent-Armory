
Note of the Author

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the links to purchase full version and commercial license:
	https://www.creativefabrica.com/product/streetwall/ref/379154/

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at grewfont.studio@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/BalconyGraphics


Please visit our folio for more amazing fonts : http://www.behance.net/grewfont

Follow our instagram for update : @grewfont

Thank you.

-------------------

INDONESIAN TRANSLATION :

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.   

- Silakan gunakan lisensi komersial dengan membeli melalui link-link ini :
	https://www.creativefabrica.com/product/streetwall/ref/379154/

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan Corporate License.

- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya CORPORATE LICENSE.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : grewfont.studio@gmail.com


Terima kasih.