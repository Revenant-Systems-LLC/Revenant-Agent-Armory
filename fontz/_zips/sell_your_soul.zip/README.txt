Sell Your Soul Font By Chris Hansen.
www.geocities.com/crizcrack666