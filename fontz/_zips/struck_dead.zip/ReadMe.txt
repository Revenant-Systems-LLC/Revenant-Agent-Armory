STRUCK DEAD
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

The extreme stressing on this font is madness with a particular method, including a kind of offset "ink shadow" common to some kinds of ailing presses. It's a look I see a lot in old pulp magazines, and since that's where I've been spending a lot of mental time, lately, I had it in my head that I'd have to play around with that look next time I needed to make a stressed font for a project. The result is probably the most tortured-looking font I've done so far.

An interesting challenge was the spacing and kerning. I couldn't rely much at all on any kind of automated process, since the little bits of "print junk" would confuse any such method into uselessness. I'm pretty happy with what I came up with for the kerning, but I'll probably keep fiddling with it in future versions; drop me a line if there's a kerning pair you'd like to see improved.

Struck Dead is a full-keyboard font with no extended characters. It's designed for sizes between 12 and 36 points or so.

This font is copyright 2003 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
